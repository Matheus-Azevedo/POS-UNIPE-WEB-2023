package com.posunipe.backend.apisports;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApisportsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApisportsApplication.class, args);
	}

}
